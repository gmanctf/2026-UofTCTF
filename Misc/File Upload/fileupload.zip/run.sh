#!/bin/bash

docker build -t uoftctf-fileupload .

docker run -it --rm -p 5000:5000 --tmpfs /tmp:rw,exec,size=30m -t uoftctf-fileupload