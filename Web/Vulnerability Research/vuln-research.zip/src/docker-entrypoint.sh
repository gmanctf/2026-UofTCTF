#!/bin/sh
set -e
exec python3 -u web2py/web2py.py -a "$(openssl rand -base64 32 | tr -d '=')" -i 0.0.0.0 -p 5000 -c /opt/ssl/cert.pem -k /opt/ssl/key.pem -v
