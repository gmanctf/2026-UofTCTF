#!/bin/bash

cd /app
exec python3 ./chall.py
